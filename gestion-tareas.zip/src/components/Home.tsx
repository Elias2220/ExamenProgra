import React from 'react';

const Home: React.FC = () => {
  return (
    <div>
      <h1>Bienvenido a la Gestión de Tareas</h1>
      <p>Esta es la página de inicio donde puedes ver la información personal del usuario o cualquier otro contenido relevante.</p>
    </div>
  );
};

export default Home;
